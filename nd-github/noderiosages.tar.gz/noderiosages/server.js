import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import path from 'path';
import {
    fileURLToPath
} from 'url';
import jwt from 'jsonwebtoken';


dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 2000;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const USERNAME = "rioard-dev";
const TOKEN = process.env.GITHUB_TOKEN;
const JWT_SECRET = process.env.JWT_SECRET; // Use a strong secret in production!

if (!TOKEN) {
    console.warn("⚠️  GITHUB_TOKEN tidak ditemukan di .env");
}

const CACHE_DURATION = parseInt(process.env.CACHE_DURATION) || 10 * 60 * 1000; // 10 menit

let cache = {
    user: null,
    repos: null,
    timestamp: 0
};

async function githubFetch(endpoint) {
    const res = await fetch(`https://api.github.com${endpoint}`, {
        headers: {
            'Authorization': `token ${TOKEN}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'rioard-dev-portfolio'
        }
    });

    if (res.status === 403) throw new Error('Rate limit exceeded');
    if (!res.ok) throw new Error(`GitHub API error: ${res.status} ${res.statusText}`);

    return res.json();
}

// Middleware untuk verifikasi token (Authentikasi)
const authenticate = (req, res, next) => {
    const payload = {
        status: 'success'
    };

    const accessToken = jwt.sign(payload, JWT_SECRET, {
        expiresIn: '1m'
    });

    if (!accessToken) return res.status(401).json({
        error: 'No token'
    });

    try {
        const decoded = jwt.verify(accessToken,req.params.token);
        req.token = decoded;
        next(); // lanjut ke route handler
    } catch (err) {
        return res.status(403).json({
            message: 'Invalid or expired token'
        });
    }
};
// Endpoint utama
app.get('/api/:token/github', authenticate, async (req, res) => {
    const forceRefresh = req.query.refresh === 'true';
    if (!req.token && !forceRefresh && cache.user && Date.now() - cache.timestamp < CACHE_DURATION) {
        return res.json({
            user: cache.user, repos: cache.repos, status: 'no token'
        });
    }

    try {
        const [user,
            repos] = await Promise.all([
                githubFetch(`/users/${USERNAME}`),
                githubFetch(`/users/${USERNAME}/repos?sort=updated&per_page=9`)
            ]);

        cache = {
            user,
            repos,
            timestamp: Date.now()
        };

        res.json({
            user, repos
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: error.message.includes('Rate limit')
            ? 'Rate limit tercapai. Tunggu beberapa menit.': 'Gagal mengambil data dari GitHub.'
        });
    }
});

// Endpoint single repo + README
app.get('/api/:token/repo/:reponame', authenticate, async (req, res) => {
    const {
        reponame
    } = req.params;
    if (!req.token) return res.status(401).json({
        error: 'No token'
    });
    try {
        const repo = await githubFetch(`/repos/${USERNAME}/${reponame}`);

        let readmeHTML = '<p class="text-gray-500 italic">README.md tidak ditemukan.</p>';

        try {
            const readme = await githubFetch(`/repos/${USERNAME}/${reponame}/readme`);
            const content = Buffer.from(readme.content, 'base64').toString('utf-8');

            // Markdown sederhana ke HTML (bisa diganti dengan marked.js nanti)
            let html = content
            .replace(/^### (.*$)/gm, '<h3 class="text-lg font-semibold mt-6 mb-2">$1</h3>')
            .replace(/^## (.*$)/gm, '<h2 class="text-xl font-semibold mt-8 mb-3">$1</h2>')
            .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold mt-8 mb-4">$1</h1>')
            .replace(/^\* (.*$)/gm, '<ul class="list-disc ml-6"><li>$1</li></ul>')
            .replace(/\n/g, '<br>');

            readmeHTML = `<div class="whitespace-pre-wrap">${html}</div>`;
        } catch (e) {
            // README tidak wajib
        }

        res.json({
            repo, readmeHTML
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: 'Gagal memuat repository'
        });
    }
});

app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});